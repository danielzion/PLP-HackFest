`use strict`
var datetime = new Date();
console.log(datetime);
document.getElementById('time').textContent = datetime;